from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("signup/", views.signup, name="signup"),
    path("login/", views.login, name="login"),
    path("homepage/<int:student_id>/", views.homepage, name="homepage"),
    path("teachers/", views.teachers, name="teachers"),
    path("promotion/", views.promotion, name="promotion"),
    path('staff/login/', views.staff_login, name='staff_login'),
    path('staff/dashboard/', views.staff_subject_and_student_details, name='staff_dashboard'),
    path("subject_list/<int:student_id>/", views.subject_list, name="subject_list"),
    path("subject_details/", views.subject_details, name="subject_details"),
    path('subject_details/', views.subject_details, name='subject_details'),  # Assuming you have this view
    path('admin/login/', views.admin_login, name='admin_login'),
    path('admin/dashboard/', views.subject_and_student_details, name='admin_dashboard'),
    path('my_page/teachers/', views.teachers, name='teachers'),
    path('admin/edit_subject/<int:subject_id>/', views.edit_subject_admin, name='admin_edit_subject'),
    path('admin/dashboard/', views.subject_and_student_details, name='admin_dashboard'),
    path('updatesubject/<str:subject_id>/', views.updatesubject, name='updatesubject'),
]
