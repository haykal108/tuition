from django.contrib import admin
from student.models import Student, Subject, Payment, Staff , AdminUser

# Register your models here.
admin.site.register(Student),
admin.site.register(Subject),
admin.site.register(Payment),
admin.site.register(Staff),
admin.site.register(AdminUser),