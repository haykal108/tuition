from django.shortcuts import render

# Create your views here.
from django.shortcuts import render , get_list_or_404 , get_object_or_404 , redirect
from django.http import HttpResponse
from django.contrib.auth import authenticate, login as auth_login
from .models import Student, Subject, Staff, AdminUser , Payment
from django.urls import reverse
from django.contrib import messages
from django.http import HttpResponseRedirect




def index(request):
    return render(request, "index.html")

def signup(request):
    displaydata = Student.objects.all().values()
    if request.method == 'POST':
        username1 = request.POST('username')
        email1 = request.POST('email')
        password1 = request.POST('password')
        phone_number1 = request.POST('phone_number')

        student = Student(username=username1, email=email1, password=password1, phone_number=phone_number1)
        student.save()

        context = {
           'displaydata': displaydata,
            'message': 'Account created successfully'
        }

        return render(request, "signup.html", context)
    else:
        dict={
            'message': '',
            'displaydata': displaydata
        }
        return render(request, "signup.html", dict)
    
def login(request):
    error_message = None
    profile = None

    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        try:
            profile = Student.objects.get(username=username, password=password)
        except Student.DoesNotExist:
            error_message = "Invalid username or password"
        
        if profile:
            student_id = profile.student_id
            homepage_url = reverse('homepage', args=[student_id])
            return HttpResponseRedirect(homepage_url)
    
    return render(request, "login.html", {'error_message': error_message})




def homepage(request, student_id):
    try:
        profile = Student.objects.get(student_id=student_id)
    except Student.DoesNotExist:
        return render(request, "error.html", {"error_message": "Profile not found"})
    
    return render(request, "homepage.html", {'profile': profile, 'student_id': student_id})

def subject_list(request, student_id):
    subjects = Subject.objects.all()
    return render(request, "subjects.html", {'subjects': subjects, 'student_id': student_id})

def subject_details(request):
    subject_ids = request.GET.getlist('subject_ids')
    if not subject_ids:
        return render(request, 'subject_details.html', {'subjects': [], 'total_price': 0})
    
    subjects = get_list_or_404(Subject, pk__in=subject_ids)
    total_price = sum(subject.price for subject in subjects)
    
    return render(request, 'subject_details.html', {'subjects': subjects, 'total_price': total_price})

    

def teachers(request):
    student_id = 1
    context = {'student_id': student_id}
    return render(request, "teachers.html", context)



def promotion(request):
    return render(request, "promotion.html")


def staff_login(request):
    error_message = None
    profile = None

    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        
        try:
            profile = Staff.objects.get(username=username, password=password)
        except Staff.DoesNotExist:
            error_message = "Invalid username or password"
        
        if profile:
            staff_dashboard_url = reverse('staff_dashboard')
            return HttpResponseRedirect(staff_dashboard_url)
        
    return render(request, "staff_login.html", {'error_message': error_message})


def staff_subject_and_student_details(request):
    subjects = Subject.objects.all()  # Fetch all subjects from your database
    students = Student.objects.all()  # Fetch all students from your database
    context = {
        'subjects': subjects,
        'students': students
    }
    return render(request, 'staff_dashboard.html', context)


def admin_login(request):
    error_message = None
    profile = None

    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        
        try:
            profile = AdminUser.objects.get(username=username, email=email)
        except AdminUser.DoesNotExist:
            error_message = "Invalid username or password"
        
        if profile:
            admin_dashboard_url = reverse('admin_dashboard')
            return HttpResponseRedirect(admin_dashboard_url)
        
    return render(request, "admin_login.html", {'error_message': error_message})


def subject_and_student_details(request):
    subjects = Subject.objects.all()  # Fetch all subjects from your database
    students = Student.objects.all()  # Fetch all students from your database
    payments = Payment.objects.select_related('student', 'subject').all()

    context = {
        'subjects': subjects,
        'students': students,
        'payments': payments,
    }

    if request.method == 'POST':
        # Extract data from POST request
        student_id = request.POST.get('student_id')
        subject_id = request.POST.get('subject_id')
        amount = request.POST.get('amount')
        

        # Retrieve student and subject instances
        student = get_object_or_404(Student, id=student_id)
        subject = get_object_or_404(Subject, id=subject_id)

        # Create and save a new Payment instance
        payment = Payment(
            student=student,
            subject=subject,
            amount=amount,
        )
        payment.save()

        # Redirect to admin_dashboard after saving
        return HttpResponseRedirect('/admin_dashboard/')

    return render(request, 'admin_dashboard.html', context)
        

def edit_subject_admin(request, subject_id):
    subject = get_object_or_404(Subject, pk=subject_id)
    
    if request.method == 'POST':
        # Retrieve updated data from the form
        name = request.POST.get('name')
        description = request.POST.get('description')
        grade_level = request.POST.get('grade_level')
        teacher = request.POST.get('teacher')
        price = request.POST.get('price')
        
        # Update the subject object with new data
        subject.name = name
        subject.description = description
        subject.grade_level = grade_level
        subject.teacher = teacher
        subject.price = price
        
        # Save the updated subject object
        subject.save()
        
        # Optionally, add a success message
        messages.success(request, 'Subject updated successfully.')
        
        # Redirect back to admin dashboard or any other page
        return HttpResponseRedirect(reverse('admin_dashboard'))
    
    # Render the edit form initially with existing subject data
    return render(request, 'admin_editsubject.html', {'subject': subject})


#update data subject___________________________________________________________________________

def updatesubject(request, subject_id):
    data = get_object_or_404(Subject, subject_id=subject_id)

    if request.method == 'POST':
        # Get the updated values from the POST request
        subject_name = request.POST.get('name')
        subject_desc = request.POST.get('desc')
        grade_lvl = request.POST.get('grade')
        teacher = request.POST.get('teacher')
        price = request.POST.get('price')

        # Update the data fields
        data.name = subject_name
        data.description = subject_desc
        data.grade_level = grade_lvl
        data.teacher = teacher
        data.price = price

        data.save()

        return redirect('admin_dashboard')  # Redirect to the list of subjects after updating

    return render(request, 'admin_editsubject.html', {'data': data})

 
def addsubject(request):
    return render(request, "addsubject.html")
from django.shortcuts import render, redirect
from .models import Subject

def createnewsubject(request):
    if request.method == 'POST':
        # Get data from the POST request
        name = request.POST.get('name')
        description = request.POST.get('description')
        grade_level = request.POST.get('grade_level')
        teacher = request.POST.get('teacher')
        price = request.POST.get('price')

        # Create a new Subject instance and save it to the database
        new_subject = Subject(name=name, description=description, grade_level=grade_level, teacher=teacher, price=price)
        new_subject.save()

        return redirect('createnewsubject')  # Redirect to a success page or another view

    return render(request, 'addsubject.html')

def deletesubject(request, subject_id):
    # Get the NutritionLog instance to be deleted, or return a 404 response if it doesn't exist
    data = get_object_or_404(Subject, subject_id=subject_id)

    if request.method == 'POST':
        # If a POST request is received, delete the instance and redirect to a specific page
        data.delete()
        return redirect('admin_dashboard')




def addsubjectstaff(request):
    return render(request, "addsubjectstaff.html")
from django.shortcuts import render, redirect
from .models import Subject

def createnewsubjectstaff(request):
    if request.method == 'POST':
        # Get data from the POST request
        name = request.POST.get('name')
        description = request.POST.get('description')
        grade_level = request.POST.get('grade_level')
        teacher = request.POST.get('teacher')
        price = request.POST.get('price')

        # Create a new Subject instance and save it to the database
        new_subject = Subject(name=name, description=description, grade_level=grade_level, teacher=teacher, price=price)
        new_subject.save()

        return redirect('createnewsubjectstaff')  # Redirect to a success page or another view

    return render(request, 'addsubjectstaff.html')